package de.unimannheim.textprocessing.parsers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ximpleware.AutoPilot;
import com.ximpleware.NavException;
import com.ximpleware.ParseException;
import com.ximpleware.VTDGen;
import com.ximpleware.VTDNav;

public class GigawordCorpusDocumentParser implements
		Iterable<GigawordCorpusDocument>, Iterator<GigawordCorpusDocument> {

	private static final Logger log = LogManager
			.getLogger(GigawordCorpusDocumentParser.class);

	private boolean hasNext;
	private int numDocs;

	private VTDNav vn;
	private AutoPilot docAp;
	

	public GigawordCorpusDocumentParser(String inputFile) {
		try {
			// Read the file into a byte array
			log.info("Reading file into byte array");
			File f = new File(inputFile);
			InputStream fis = new FileInputStream(f);
			log.info("File size: " + f.length());
			byte[] b = new byte[(int) f.length()];
			fis.read(b);
			fis.close();

			init(b);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public GigawordCorpusDocumentParser(byte[] b) {
		init(b);
	}

	private void init(byte[] b) {
		try {
			// Index the xml with VTD-XML
			log.info("Building VTD index");
			VTDGen vg = new VTDGen();
			vg.setDoc(b);
			vg.parse(false);
			vn = vg.getNav();

			numDocs = 0;
			vn.toElement(VTDNav.ROOT);

			// Initialize auto pilot
			init();
		} catch (NavException e) {
			throw new RuntimeException(e);
		} catch (ParseException e) {
			//System.out.println(e.getStackTrace());
			throw new RuntimeException(e);
		}
	}

	private void init() {
		try {
			docAp = new AutoPilot(this.vn);
			docAp.selectElement(Constants.DOC);
			hasNext = docAp.iterate();
		} catch (NavException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public Iterator<GigawordCorpusDocument> iterator() {
		return this;
	}

	@Override
	public boolean hasNext() {
		return hasNext;
	}

	@Override
	public GigawordCorpusDocument next() {
		try {
			String docId = vn.toString(vn.getAttrVal(Constants.DOC_ID));
			String docType = vn.toString(vn.getAttrVal(Constants.DOC_TYPE));
			//System.out.println(docId);
			log.info("doc id=" + docId);
			log.info("doc type=" + docType);

			GigawordCorpusDocument gigaWordDoc = new GigawordCorpusDocument();
			gigaWordDoc.setDocId(docId);
			gigaWordDoc.setType(docType);

			// Read the headline (if it exists)
			gigaWordDoc.setHeadline(parseHeadline(vn.cloneNav()));

			// Read the dateline (if it exists)
			gigaWordDoc.setDateline(parseDateline(vn.cloneNav()));

			// Read the text 
			gigaWordDoc.setText(parseText(vn.cloneNav()));

			numDocs++;

			hasNext = docAp.iterate();

			return gigaWordDoc;
		} catch (NavException e) {
			throw new RuntimeException(e);
		}
	}

	public int getNumDocs() {
		return numDocs;
	}

	/**
	 * Parses out the HEADLINE element, which is a parse of the dateline if it
	 * exists.
	 * 
	 * Assumes the position of vn is at a "DOC" tag
	 */
	private String parseHeadline(VTDNav vn) throws NavException {
		require(vn.matchElement(Constants.DOC));
		if (!vn.toElement(VTDNav.FIRST_CHILD, Constants.HEADLINE)
				|| vn.getText() == -1) {
			// If there is no headline annotation return the empty list
			log.warn("No headline found");
			return null;
		}
		return vn.toString(vn.getText()).trim();
	}

	/**
	 * Parses out the DATELINE element, which is a parse of the dateline if it
	 * exists.
	 * 
	 * Assumes the position of vn is at a "DOC" tag
	 */
	private String parseDateline(VTDNav vn) throws NavException {
		require(vn.matchElement(Constants.DOC));
		if (!vn.toElement(VTDNav.FIRST_CHILD, Constants.DATELINE)
				|| vn.getText() == -1) {
			// If there is no dateline annotation return the empty list
			log.warn("No dateline found");
			return null;
		}
		return vn.toString(vn.getText()).trim();
	}

	private String parseText(VTDNav vn) throws NavException {
		require(vn.matchElement(Constants.DOC));
		StringBuffer sb = new StringBuffer();
		String returnVal = null;
		
		
		 
		if (vn.toElement(VTDNav.FIRST_CHILD, Constants.TEXT)) {
			
			//System.out.println(vn.getText());
			
			if(vn.getText() == -1) {
			
				if(vn.toElement(VTDNav.FIRST_CHILD,Constants.P_TAG)){
	                do{
	                	sb.append(toNormalizedStringText(Constants.P_TAG, vn) + "\n");
	                	
	                }while(vn.toElement(VTDNav.NEXT_SIBLING,Constants.P_TAG));
	            }
			} else {
				sb.append(toNormalizedStringText(Constants.TEXT, vn) + "\n");
			}
			
			if (sb.length() > 0) {
				sb.setLength(sb.length() - 1);
				returnVal = sb.toString();
			}
		}
		return returnVal.length() > 0 ? returnVal : null;
	}
	
	private static String toNormalizedStringText(String tagName, final VTDNav vn) throws NavException{
        return toNormalizedString(tagName, vn.getText(), vn);
	}
	
	private static String toNormalizedString(String name, int val, final VTDNav vn) throws NavException{

        String strValue = null;
        if(val != -1){
              strValue = vn.toNormalizedString(val);
              //System.out.println(name + ":: " + strValue);
        }
        return strValue;
	}


	// any call to require should also have a message explaining what
	// condition wasn't met
	public static void require(boolean truth) {
		if (!truth) {
			throw new IllegalStateException();
		}
	}

	@Override
	public void remove() {
		throw new RuntimeException("not implemented");       
	}

}
