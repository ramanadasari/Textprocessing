/**
 * 
 */
package de.unimannheim.textprocessing.parsers;

/**
 * @author D063458
 *
 */
public class Constants {
	
	public static final String FILE = "FILE";
	public static final String FILE_ID = "id";

	public static final String DOC = "DOC";

	public static final String HEADLINE = "HEADLINE";
	public static final String DATELINE = "DATELINE";

	// XML Attribute names
	public static final String DOC_ID = "id";
	public static final String DOC_TYPE = "type";
	public static final String TEXT = "TEXT";
	
	public static final String P_TAG = "P";

}
