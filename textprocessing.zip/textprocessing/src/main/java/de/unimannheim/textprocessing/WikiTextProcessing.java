/**
 * 
 */
package de.unimannheim.textprocessing;

import java.io.Serializable;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import de.tudarmstadt.ukp.wikipedia.datamachine.domain.JWPLDataMachine;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;

/**
 * @author D063458
 */
public class WikiTextProcessing extends BaseTextProcessing implements Serializable, Runnable {

	private static final long serialVersionUID = 1L;
	private static final Logger logger = LogManager.getLogger(WikiTextProcessing.class);

	private String directoryName;
	private String fileExtension;

	public WikiTextProcessing() {}
	public WikiTextProcessing(String directoryName, String fileExtension, StanfordCoreNLP pipeline,
			long lastUpdatedTime) {
		this.directoryName = directoryName;
		this.fileExtension = fileExtension;
		setPipeline(pipeline);
		setLastUpdatedTime(lastUpdatedTime);
	}

	/**
	 * 
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		
		convertDumptoTextFiles();
		
//		File[] files = getFiles(directoryName, fileExtension);
//
//		if (files.length > 0) {
//			try {
//				for (File inputFile : files) {
//
//					String documentText = FileUtils.readFileToString(inputFile, Charset.forName("UTF8"));
//
//					// get a ParsedPage object
//					MediaWikiParserFactory pf = new MediaWikiParserFactory();
//					MediaWikiParser parser = pf.createParser();
//					ParsedPage pp = parser.parse(documentText);
//
//					// parse the file
//					parseFile(directoryName,inputFile.getName(), getPipeline(), 
//							pp.getText(), "",
//							pp.getLinks().iterator().next().getHomeElement().getText());
//				}
//			} catch (IOException e) {
//				logger.error(e.getMessage());
//			}
//		} else {
//			logger.warn("No file exist");
//		}
//
//		timeforProcessing(getLastUpdatedTime(), null, 0);
	}
	
	

	public void convertDumptoTextFiles() {
		
		String[] command = new String[4];
		
		command[0] = "english";
		command[1] = "Contents";
		command[2] = "Disambiguation";
		command[3] = directoryName;
		
		JWPLDataMachine.main(command);

//		File dir = new File("src"+File.separator+"lib");
//		//System.out.println(dir.getAbsolutePath());
//		FileFilter fileFilter = new WildcardFileFilter("datamachine*.jar");
//		File[] files = dir.listFiles(fileFilter);
//
//		File jarFile = files[0];
//
//		if (jarFile.exists()) {
//
//			String[] command = new String[7];
//			command[0] = "java.exe";
//			command[1] = "-jar";
//			command[2] = jarFile + "";
//			command[3] = "english";
//			command[4] = "Contents";
//			command[5] = "Disambiguation";
//			command[6] = directoryName + "/dump";
//
//			// String command = "java -jar "+jarFile+" english Contents
//			// Disambiguation ./";
//			try {
//
//				Process process = Runtime.getRuntime().exec(command);
//				//process.waitFor();
//				logger.info(process.getInputStream());
//
//			} catch (IOException e) {
//				logger.error(e.getMessage());
//			}
////			} catch (InterruptedException e) {
////				logger.error(e.getMessage());
////			}

//		} else {
//			System.out.println("File is not available");
//		}

	}

}
