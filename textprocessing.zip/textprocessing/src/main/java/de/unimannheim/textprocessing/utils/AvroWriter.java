/**
 * 
 */
package de.unimannheim.textprocessing.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;

import org.apache.avro.Schema;
import org.apache.avro.file.DataFileReader;
import org.apache.avro.file.DataFileWriter;
import org.apache.avro.io.DatumReader;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.specific.SpecificDatumReader;
import org.apache.avro.specific.SpecificDatumWriter;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.component.JCasConsumer_ImplBase;
import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;

import de.tudarmstadt.ukp.dkpro.core.api.lexmorph.type.pos.POS;
import de.tudarmstadt.ukp.dkpro.core.api.ner.type.NamedEntity;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import de.unimannheim.textprocessing.BaseTextProcessing;
import de.unimannheim.textprocessing.pojo.Row;
import de.unimannheim.textprocessing.pojo.Sentences;
import de.unimannheim.textprocessing.pojo.TextProcessing;
import de.unimannheim.textprocessing.pojo.Tokens;

/**
 * @author D063458
 *
 */
public class AvroWriter extends JCasConsumer_ImplBase {

	private static final Logger logger = LogManager.getLogger(AvroWriter.class);

	private DataFileWriter<TextProcessing> dataFileWriter;

	@Override
	public void process(JCas aJCas) throws AnalysisEngineProcessException {

		File inputDirectory = new File("C:\\textProcessing");
		File outputDirectorypath = new File(inputDirectory.getAbsolutePath()
				+ "\\output");
		File outputFile = new File(outputDirectorypath, "text" + ".avro");

		if (!outputDirectorypath.exists()) {
			outputDirectorypath.mkdirs();
		}

		try {
			getDataFileWriter(outputFile);

			TextProcessing jsonTextProcessing = new TextProcessing();

			Sentences jsonSentence = null;
			List<Sentences> jsonSentenceArr = new ArrayList<Sentences>();

			/* all sentences */
			for (Sentence sentence : JCasUtil.select(aJCas, Sentence.class)) {

				HashMap<Token, Row> ctokens = new LinkedHashMap<Token, Row>();

				// Tokens
				List<Token> tokens = JCasUtil.selectCovered(Token.class,
						sentence);

				int rowId = 0;
				for (Token token : tokens) {
					Row row = new Row();
					row.id = rowId + 1;
					row.token = token;
					ctokens.put(row.token, row);
					rowId++;
				}

				jsonSentence = new Sentences();
				List<Tokens> jsontokenArr = new ArrayList<Tokens>();
				/* all Noun Phrases within that sentence */
				for (Row row : ctokens.values()) {

					Tokens jsonToken = new Tokens();

					Token token = row.token;
					String word = token.getCoveredText();
					String lemma = token.getLemma().getValue();
					NamedEntity ne = JCasUtil
							.selectCovered(aJCas, NamedEntity.class, token)
							.iterator().next();
					POS pos = JCasUtil.selectCovered(aJCas, POS.class, token)
							.iterator().next();

					jsonToken.setIndex(row.id);
					jsonToken.setLemma(lemma);
					jsonToken.setNer(ne.getValue());
					jsonToken.setPos(pos.getPosValue());
					jsonToken.setToken(word);

					jsontokenArr.add(jsonToken);

					System.out.println("word:" + word + ",lemma:" + lemma
							+ ",ne:" + ne + ",pos:" + pos);

				}

				// Dependencies
				// for (Dependency rel :
				// JCasUtil.selectCovered(Dependency.class,
				// sentence)) {
				// // ctokens.get(rel.getDependent()).deprel = rel;
				// }

				jsonSentence.setTokens(jsontokenArr);
				jsonSentenceArr.add(jsonSentence);
			}

			jsonTextProcessing.setSentences(jsonSentenceArr);
			append(jsonTextProcessing);
			close();
			converttoJsonReader(outputFile,outputFile);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void append(TextProcessing jsonText) throws IOException {
		dataFileWriter.append(jsonText);
	}

	/**
	 * convert the avro file to json file
	 * 
	 * @param file
	 * @throws IOException
	 */
	public static void converttoJsonReader(File file,
			File outputDirectorypathForJson) throws IOException {
		// Deserialize Users from disk
		DatumReader<TextProcessing> userDatumReader = new SpecificDatumReader<TextProcessing>(
				TextProcessing.class);
		DataFileReader<TextProcessing> dataFileReader = new DataFileReader<TextProcessing>(
				file, userDatumReader);

		TextProcessing text = null;
		StringBuilder jsontext = new StringBuilder();
		while (dataFileReader.hasNext()) {
			// Reuse user object by passing it to next(). This saves us from
			// allocating and garbage collecting many objects for files with
			// many items.
			text = dataFileReader.next(text);
			jsontext.append(text);
			// logger.info(text);
		}
		// write the json output file
		File outputJsonFile = new File(outputDirectorypathForJson.getAbsolutePath(),
				BaseTextProcessing.removeExtension(file.getName()) + ".json");
		writeToJsonFile(outputJsonFile, jsontext.toString());
		dataFileReader.close();
	}

	/**
	 * write the Json file
	 * 
	 * @param outputFile
	 * @param fileWriter
	 * @param jsonOutput
	 */
	protected static void writeToJsonFile(File outputFile, String jsonOutput) {
		try {

			// checking whether the file exist
			if (!outputFile.exists()) {
				outputFile.createNewFile();
			} else {
				outputFile.delete();
				outputFile.createNewFile();
			}

			FileWriter fileWriter = new FileWriter(outputFile.getAbsoluteFile());

			BufferedWriter bufferWriter = new BufferedWriter(fileWriter);
			bufferWriter.write(jsonOutput);
			bufferWriter.close();

		} catch (FileNotFoundException e) {
			logger.error("File Not Found Exception" + e.getMessage());
		} catch (IOException e) {
			logger.error("IO Exception" + e.getMessage());
		}
	}

	/**
	 * @return the dataFileWriter
	 * @throws IOException
	 */
	public DataFileWriter<TextProcessing> getDataFileWriter(File file)
			throws IOException {
		LoadProperties loadProperties = new LoadProperties();
		loadProperties.read();
		Properties props = loadProperties.getProperties();

		ClassLoader classLoader = getClass().getClassLoader();

		File schemaFile = new File(classLoader.getResource(
				props.getProperty("schemaFileName")).getFile());

		Schema schema = new Schema.Parser().parse(schemaFile);

		DatumWriter<TextProcessing> datumWriter = new SpecificDatumWriter<TextProcessing>(
				TextProcessing.class);

		dataFileWriter = new DataFileWriter<TextProcessing>(datumWriter);
		dataFileWriter.create(schema, file);

		return dataFileWriter;
	}

	/**
	 * @param dataFileWriter
	 *            the dataFileWriter to set
	 */
	public void setDataFileWriter(DataFileWriter<TextProcessing> dataFileWriter) {
		this.dataFileWriter = dataFileWriter;
	}

	/**
	 * close the par
	 */
	public void close() throws IOException {
		dataFileWriter.close();
	}

}
