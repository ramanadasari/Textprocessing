/**
 * 
 */
package de.unimannheim.textprocessing;

import java.util.Properties;

import edu.stanford.nlp.pipeline.StanfordCoreNLP;

/**
 * @author D063458
 *
 */
public class MainTextProcessing {

	/**
	 * main method for calling all the parsers
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		long lastUpdatedTime = System.currentTimeMillis();
		StanfordCoreNLP pipeline = initializePipeline();
		
		Thread t1 =new Thread(new NYTTextProcessing("nytimes",".xml",pipeline,lastUpdatedTime));
		Thread t2 =new Thread(new GigawordTextProcessing("gigaword", ".gz",pipeline,lastUpdatedTime));  
		//Thread t3 =new Thread(new WikiTextProcessing("wiki", ".",pipeline,lastUpdatedTime));
		
		t1.start();
		t2.start();
		//t3.start();
		
		//new WikiTextProcessing().convertDumptoTextFiles();
	}
	
	/**
	 * initialize the standford Pipeline
	 * @return StanfordCoreNLP
	 */
	private static StanfordCoreNLP initializePipeline() {
		
		Properties props = new Properties();
		props.setProperty("annotators","tokenize,ssplit,pos,lemma,ner,regexner,parse,dcoref");

		// props.put("regexner.mapping", "regexp.txt");
		int cores = Runtime.getRuntime().availableProcessors();
		props.put("threads", cores);

		return new StanfordCoreNLP(props);
	}

}
