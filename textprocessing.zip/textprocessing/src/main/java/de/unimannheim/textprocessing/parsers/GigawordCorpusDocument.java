package de.unimannheim.textprocessing.parsers;

import java.io.Serializable;
import java.util.Arrays;

public class GigawordCorpusDocument implements Serializable {
	
	
	public static final long serialVersionUID = 1;

    private String docId;
    private String type;
    private String headline;
    private String dateline;
    
    private String text;
    
    
    
    /**
	 * @return the text
	 */
	public String getText() {
		return text;
	}

	/**
	 * @param text the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}

	public String getDocId() {
        return docId;
    }

    public void setDocId(String id) {
        this.docId = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
        
    public String getHeadline() {
        return headline;
    }

    public void setHeadline(String headline) {
        this.headline = headline;
    }

    public String getDateline() {
        return dateline;
    }

    public void setDateline(String dateline) {
        this.dateline = dateline;
    }

    

    @Override
    public boolean equals(Object other) {
        if(other == null) return false;
        if(other instanceof GigawordCorpusDocument) {
            GigawordCorpusDocument o = (GigawordCorpusDocument) other;
            return safeEquals(docId, o.docId)
                    && safeEquals(type, o.type)
                    && safeEquals(headline, o.headline)
                    && safeEquals(dateline, o.dateline);
        }
        return false;
    }
    
    
    
    
    
    
    
    	
    public static boolean safeEquals(Object a, Object b) {
        if (a == null && b == null) {
            return true;
        } else if (a == null) {
            return false;
        } else if (b == null) {
            return false;
        } else {
            return a.equals(b);
        }
    }
    
    public static int safeHashCode(Object... objects) {
        return Arrays.hashCode(objects);
    }
    
    @Override
    public int hashCode() {
        return safeHashCode(docId, type, headline, dateline);
    }
}
