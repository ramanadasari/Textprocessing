/**
 * 
 */
package de.unimannheim.textprocessing.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author D063458
 *
 */
public class LoadProperties {

	private static final Logger logger = LogManager.getLogger(LoadProperties.class);
	private Properties properties;
	
	public LoadProperties() {
		setProperties(new Properties());
	}
	
	
	public void read() {
		InputStream in = this.getClass().getResourceAsStream(
				"/resource.properties");
		
		try {
			properties.load(in);
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
	}


	public Properties getProperties() {
		return properties;
	}


	public void setProperties(Properties properties) {
		this.properties = properties;
	}
	
	
}
