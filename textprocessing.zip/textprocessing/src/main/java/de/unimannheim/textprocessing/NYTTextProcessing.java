package de.unimannheim.textprocessing;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import de.unimannheim.textprocessing.parsers.NYTCorpusDocument;
import de.unimannheim.textprocessing.parsers.NYTCorpusDocumentParser;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;

public class NYTTextProcessing extends BaseTextProcessing implements Serializable, Runnable {

	
	private static final long serialVersionUID = 1L;
	
	
	private static final Logger logger = LogManager
			.getLogger(NYTTextProcessing.class);
	
	private String directoryName;
	private String fileExtension;
	
	public NYTTextProcessing(String directoryName,String fileExtension,StanfordCoreNLP pipeline,long lastUpdatedTime) {
		this.directoryName = directoryName;
		this.fileExtension = fileExtension;
		setPipeline(pipeline);
		setLastUpdatedTime(lastUpdatedTime);
	}

	/**
	 * 
	 * @param args
	 */
	@Override
	public void run() {

		File[] files = getFiles(directoryName,fileExtension);
		
		if (files.length > 0) {
			NYTCorpusDocumentParser nytCorpusDocumentParser = null;
			
			try {
				for (File inputFile : files) {
					
					// parsing the xml file
					nytCorpusDocumentParser = new NYTCorpusDocumentParser();
					NYTCorpusDocument nytCorpusDocument = nytCorpusDocumentParser
							.parseNYTCorpusDocumentFromFile(inputFile, false);
					
					// parse the file
					parseFile(directoryName,inputFile.getName(), getPipeline(),
							nytCorpusDocument.getBody(),
							nytCorpusDocument.getPublicationDate(),
							nytCorpusDocument.getUrl());
				}	
			} catch (IOException e) {
				logger.error(e.getMessage());
			}
		} else {
			logger.warn("No file exist");
		}

		timeforProcessing(getLastUpdatedTime(), null, 0);
		logger.info("Total Number of Sentences: "+ getTotalNumberOfSentences());
	}
	
	

}