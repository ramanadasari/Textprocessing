/**
 * 
 */
package de.unimannheim.textprocessing;

import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngineDescription;
import static org.apache.uima.fit.factory.CollectionReaderFactory.createReader;

import java.io.IOException;

import org.apache.uima.UIMAException;
import org.apache.uima.analysis_engine.AnalysisEngineDescription;
import org.apache.uima.collection.CollectionReader;
import org.apache.uima.fit.pipeline.SimplePipeline;

import de.tudarmstadt.ukp.dkpro.core.io.text.TextReader;
import de.tudarmstadt.ukp.dkpro.core.stanfordnlp.StanfordLemmatizer;
import de.tudarmstadt.ukp.dkpro.core.stanfordnlp.StanfordNamedEntityRecognizer;
import de.tudarmstadt.ukp.dkpro.core.stanfordnlp.StanfordParser;
import de.tudarmstadt.ukp.dkpro.core.stanfordnlp.StanfordPosTagger;
import de.tudarmstadt.ukp.dkpro.core.stanfordnlp.StanfordSegmenter;
import de.unimannheim.textprocessing.utils.AvroWriter;

/**
 * @author D063458
 *
 */
public class TestPipeline {

	public static void main(String[] args) throws UIMAException, IOException {
		
		System.out.println(System.getProperty("user.home"));
		System.out.println(System.getProperty("os.name"));
		
		CollectionReader reader = createReader(TextReader.class,
				TextReader.PARAM_SOURCE_LOCATION, "C:\\textProcessing",
				TextReader.PARAM_LANGUAGE, "en", TextReader.PARAM_PATTERNS,
				new String[] { "[+]*.txt" });

		AnalysisEngineDescription seg = createEngineDescription(StanfordSegmenter.class);

		AnalysisEngineDescription ner = createEngineDescription(StanfordNamedEntityRecognizer.class);

		AnalysisEngineDescription parser = createEngineDescription(StanfordParser.class);
		
		AnalysisEngineDescription lemma = createEngineDescription(StanfordLemmatizer.class);
		
		AnalysisEngineDescription pos = createEngineDescription(StanfordPosTagger.class);
		
		//AnalysisEngineDescription coRef = createEngineDescription(StanfordCoreferenceResolver.class);

		AnalysisEngineDescription writer = createEngineDescription(AvroWriter.class);
		
		//AnalysisEngineDescription writer = createEngineDescription(Conll2006Writer.class, Conll2006Writer.PARAM_TARGET_LOCATION, "C:\\textProcessing\\output");
		
		SimplePipeline.runPipeline(reader, seg, ner, parser, lemma, pos, writer );
		
		System.out.println("End of parsing");
	} 
}
