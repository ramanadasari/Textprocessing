/**
 * 
 */
package de.unimannheim.textprocessing;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import lombok.Data;

import org.apache.avro.file.DataFileWriter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import de.unimannheim.textprocessing.pojo.Coref;
import de.unimannheim.textprocessing.pojo.Mentions;
import de.unimannheim.textprocessing.pojo.Sentences;
import de.unimannheim.textprocessing.pojo.TextProcessing;
import de.unimannheim.textprocessing.pojo.Tokens;
import de.unimannheim.textprocessing.utils.AvroWriter;
import edu.stanford.nlp.hcoref.CorefCoreAnnotations;
import edu.stanford.nlp.hcoref.data.CorefChain;
import edu.stanford.nlp.hcoref.data.CorefChain.CorefMention;
import edu.stanford.nlp.ling.CoreAnnotations.LemmaAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.NamedEntityTagAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.PartOfSpeechAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.SentencesAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.TextAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.TokensAnnotation;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.semgraph.SemanticGraph;
import edu.stanford.nlp.semgraph.SemanticGraphCoreAnnotations.BasicDependenciesAnnotation;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.trees.TreeCoreAnnotations.TreeAnnotation;
import edu.stanford.nlp.util.CoreMap;

/**
 * @author D063458
 *
 */
@Data
public class BaseTextProcessing {

	private static final Logger logger = LogManager
			.getLogger(BaseTextProcessing.class);

	private int totalNumberOfSentences = 0;
	private long lastUpdatedTime;
	private StanfordCoreNLP pipeline;
	private File inputDirectory;
	private File outputDirectorypath;
	private File outputDirectorypathForJson;
	private File outputDirectorypathForAvro;

	protected File[] getFiles(String directoryName, String fileExtension) {
		final String fileExt = fileExtension;

		String currentHomeDirectoy = System.getProperty("user.home");
		String osName = System.getProperty("os.name");

		String pathForInputDirectory = File.separator + "textProcessing"
				+ File.separator + directoryName;

		if (osName.contains("Windows")) {
			inputDirectory = new File(currentHomeDirectoy + File.separator
					+ "Documents" + pathForInputDirectory);
		} else if (osName.contains("Ubuntu")) {
			inputDirectory = new File(currentHomeDirectoy
					+ pathForInputDirectory);
		}

		outputDirectorypath = new File(inputDirectory.getAbsolutePath()
				+ File.separator + "output");

		if (!outputDirectorypath.exists()) {
			outputDirectorypath.mkdirs();
		}
		
		createOrModifyDirectories(outputDirectorypath);

		FilenameFilter filter = new FilenameFilter() {
			public boolean accept(File directory, String fileName) {
				return fileName.endsWith(fileExt);
			}
		};

		return getInputDirectory().listFiles(filter);
	}

	protected void createOrModifyDirectories(File outputDirectorypath) {
		
		outputDirectorypathForJson = new File(
				outputDirectorypath.getAbsolutePath() + File.separator + "json");
		outputDirectorypathForAvro = new File(
				outputDirectorypath.getAbsolutePath() + File.separator + "avro");
		if (!outputDirectorypathForJson.exists()) {
			outputDirectorypathForJson.mkdirs();
		}
		if (!outputDirectorypathForAvro.exists()) {
			outputDirectorypathForAvro.mkdirs();
		}
	}

	/**
	 * 
	 * @param inputFile
	 * @return
	 * @throws IOException
	 */
	protected void parseFile(String corpusName, String inputFileName,
			StanfordCoreNLP pipeline, Object... textObject) throws IOException {

		String inputText = (String) textObject[0];
		String fileNameWithOutExt = removeExtension(inputFileName);

		long lastUpdatedTime = System.currentTimeMillis();

		if (inputText == null || inputText.length() == 0) {
			return;
		}

		Annotation document = new Annotation(inputText);
		pipeline.annotate(document);

		List<CoreMap> sentences = document.get(SentencesAnnotation.class);

		int count = 1;
		Sentences jsonSentence = null;
		TextProcessing jsonTextProcessing = new TextProcessing();
		List<Sentences> jsonSentenceArr = new ArrayList<Sentences>();

		AvroWriter avroWriter = new AvroWriter();
		// write the json output file
		File outputSerializedFile = new File(outputDirectorypathForAvro,
				fileNameWithOutExt + ".avro");

		DataFileWriter<TextProcessing> dataFileWriter = avroWriter
				.getDataFileWriter(outputSerializedFile);

		for (CoreMap sentence : sentences) {
			int sentenceCount = 0;

			// traversing the words in the current sentence
			// a CoreLabel is a CoreMap with additional token-specific methods
			jsonSentence = new Sentences();
			List<Tokens> jsontokenArr = new ArrayList<Tokens>();

			for (CoreLabel token : sentence.get(TokensAnnotation.class)) {

				// System.out.println("before TextAnnotation
				// time:"+System.currentTimeMillis());
				// this is the text of the token
				String word = token.get(TextAnnotation.class);

				// this is the POS tag of the token
				String pos = token.get(PartOfSpeechAnnotation.class);

				// this is the NER label of the token
				String ne = token.get(NamedEntityTagAnnotation.class);

				// this is Lemma of the token
				String lemma = token.get(LemmaAnnotation.class);

				if (" ".equals(word)) {
					continue;
				}

				Tokens jsonToken = new Tokens();
				jsonToken.setIndex(count);
				jsonToken.setLemma(lemma);
				jsonToken.setPos(pos);
				jsonToken.setToken(word);
				if (!"O".equals(ne)) {
					jsonToken.setNer(ne);
				} else {
					jsonToken.setNer("");
				}

				jsontokenArr.add(jsonToken);

				count++;
				sentenceCount++;
			}

			// this is the ConstitencyParsing
			Tree ConstitencyParsing = sentence.get(TreeAnnotation.class);

			// this is the dependencyParsing
    		SemanticGraph dependencyParsing = sentence.get(BasicDependenciesAnnotation.class);

			int startIndex = count - sentenceCount;
			int endIndex = count - 1;

			jsonSentence.setTokens(jsontokenArr);
			jsonSentence.setFromIndex(startIndex);
			jsonSentence.setToIndex(endIndex);
			jsonSentence.setConstitencyParsing(ConstitencyParsing.toString());
     		jsonSentence.setDependencyParsing(dependencyParsing.toString());
			jsonSentenceArr.add(jsonSentence);
		}

		// start of coref
		Map<Integer, CorefChain> coref = document
				.get(CorefCoreAnnotations.CorefChainAnnotation.class);
		List<Coref> jsonCorefArr = new ArrayList<Coref>();
		for (CorefChain cc : coref.values()) {
			Coref corefObj = new Coref();
			List<CorefMention> mentionsInTextualOrder = cc
					.getMentionsInTextualOrder();
			List<Mentions> jsonMentionsArr = new ArrayList<Mentions>();

			for (CorefMention m : mentionsInTextualOrder) {
				// System.out.println("\t mentions->" + m.sentNum
				// +" "+m.mentionSpan);
				Mentions mentions = new Mentions();
				mentions.setSentencePosition(m.sentNum);
				mentions.setMentionSpan(m.mentionSpan);
				jsonMentionsArr.add(mentions);
			}
			corefObj.setCorefIndex(cc.getChainID());
			corefObj.setMentions(jsonMentionsArr);
			jsonCorefArr.add(corefObj);
		}
		jsonTextProcessing.setCoref(jsonCorefArr);
		// end of coref

		int noOfSentences = sentences.size();
		jsonTextProcessing.setDocumentID(inputFileName);

		if (textObject.length > 1) {
			Date date = (Date) textObject[1];
			if(date!=null) {
				jsonTextProcessing.setPublicationDate(date.toString());
			}
		}
		if (textObject.length > 2) {
			URL url = (URL) textObject[2];
			jsonTextProcessing.setSourceUrl(url.toString());
		}
		jsonTextProcessing.setCorpusName(corpusName);
		jsonTextProcessing.setNoOfSentences(noOfSentences);
		jsonTextProcessing.setNoOfTokens(count);
		jsonTextProcessing.setSentences(jsonSentenceArr);
		dataFileWriter.append(jsonTextProcessing);
		dataFileWriter.close();

		setTotalNumberOfSentences(getTotalNumberOfSentences() + noOfSentences);
		timeforProcessing(lastUpdatedTime, inputFileName, noOfSentences);

		// write the json output file
		File directoryForAvro = new File(outputDirectorypathForAvro,
				fileNameWithOutExt + ".avro");

		AvroWriter.converttoJsonReader(directoryForAvro,outputDirectorypathForJson);
	}
	
	public static String removeExtension(String s) {

	    String separator = System.getProperty("file.separator");
	    String filename;

	    // Remove the path upto the filename.
	    int lastSeparatorIndex = s.lastIndexOf(separator);
	    if (lastSeparatorIndex == -1) {
	        filename = s;
	    } else {
	        filename = s.substring(lastSeparatorIndex + 1);
	    }

	    // Remove the extension.
	    int extensionIndex = filename.lastIndexOf(".");
	    if (extensionIndex == -1)
	        return filename;

	    return filename.substring(0, extensionIndex);
	}

	/**
	 * Time processing
	 * 
	 * @param lastUpdatedTime
	 * @param inputFile
	 * @param sentenceSize
	 */
	protected void timeforProcessing(long lastUpdatedTime,
			String inputFileName, int sentenceSize) {
		long currentTime = System.currentTimeMillis();

		long diff = currentTime - lastUpdatedTime;

		long diffSeconds = diff / 1000 % 60;
		long diffMinutes = diff / (60 * 1000) % 60;
		long diffHours = diff / (60 * 60 * 1000) % 24;
		long diffDays = diff / (24 * 60 * 60 * 1000);

		if (inputFileName != null) {
			logger.info("File:" + inputFileName);
			logger.info("process Time:" + diffDays + " days, " + diffHours
					+ " hours, " + diffMinutes + " minutes, " + diffSeconds
					+ " seconds.");
		} else {
			logger.info("Overall process Time:" + diffDays + " days, "
					+ diffHours + " hours, " + diffMinutes + " minutes, "
					+ diffSeconds + " seconds.");
			
			if (sentenceSize > 0) {
				long avgTime = diff/sentenceSize;
				long avgSeconds = avgTime / 1000 % 60;
				long avgMinutes = avgTime / (60 * 1000) % 60;
				long avgHours = avgTime / (60 * 60 * 1000) % 24;
				long avgDays = avgTime / (24 * 60 * 60 * 1000);
				
				logger.info("Average process Time:" + avgDays + " days, "
						+ avgHours + " hours, " + avgMinutes + " minutes, "
						+ avgSeconds + " seconds.");
			}
			
		}

		if (sentenceSize > 0) {
			logger.info("No of Sentences: " + sentenceSize);
		}
	}

}
