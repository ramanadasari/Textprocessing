/**
 * 
 */
package de.unimannheim.textprocessing;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.joestelmach.natty.DateGroup;
import com.joestelmach.natty.Parser;

import de.unimannheim.textprocessing.parsers.GigawordCorpusDocument;
import de.unimannheim.textprocessing.parsers.GigawordCorpusDocumentParser;
import de.unimannheim.textprocessing.parsers.StreamingVtdXmlReader;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;

/**
 * @author D063458
 *
 */
public class GigawordTextProcessing extends
		StreamingVtdXmlReader<GigawordCorpusDocument> implements Serializable,
		Runnable {

	private static final Logger logger = LogManager
			.getLogger(GigawordTextProcessing.class);

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String directoryName;
	private String fileExtension;

	public GigawordTextProcessing() {
	}

	public GigawordTextProcessing(String directoryName, String fileExtension,
			StanfordCoreNLP pipeline, long lastUpdatedTime) {
		this.directoryName = directoryName;
		this.fileExtension = fileExtension;
		setPipeline(pipeline);
		setLastUpdatedTime(lastUpdatedTime);
	}

	public GigawordTextProcessing(String inputFile) {
		super(inputFile);
	}

	/**
	 * @param args
	 */
	@Override
	public void run() {

		File[] files = getFiles(directoryName, fileExtension);

		if (files.length > 0) {

			try {
				for (File inputFile : files) {

					GigawordTextProcessing reader = new GigawordTextProcessing(
							getInputDirectory().getAbsolutePath()
									+ File.separator + inputFile.getName());

					for (GigawordCorpusDocument doc : reader) {
						Date date = null;

						List<DateGroup> parseDateGroup = new Parser()
								.parse(doc.getDateline());
							
						if(parseDateGroup!=null
								&& parseDateGroup.size()>0){
							date = parseDateGroup.get(0).getDates().get(0);
						}
						
						String filedirectory = FilenameUtils
								.removeExtension(inputFile.getName());
						File outputDir = new File(getOutputDirectorypath()
								.getAbsolutePath()
								+ File.separator
								+ filedirectory);

						if (!outputDir.exists()) {
							outputDir.mkdirs();
						}

						createOrModifyDirectories(outputDir);

						// parse the file
						parseFile(directoryName, doc.getDocId(), getPipeline(),
								doc.getText(), date);
					}
					logger.info("Number of docs per gz file: "
							+ reader.getNumDocs());
				}

			} catch (IOException e) {
				logger.error(e.getMessage());
			}

		} else {
			logger.warn("No file exist");
		}

		// writing the Json File
		timeforProcessing(getLastUpdatedTime(), null, 0);

	}

	@Override
	protected Iterator<GigawordCorpusDocument> getIteratorInstance(byte[] b) {
		return new GigawordCorpusDocumentParser(b);
	}

}
