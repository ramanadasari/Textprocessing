/**
 * 
 */
package de.unimannheim.textprocessing.pojo;

import java.util.Collection;

import de.tudarmstadt.ukp.dkpro.core.api.coref.type.CoreferenceLink;
import de.tudarmstadt.ukp.dkpro.core.api.ner.type.NamedEntity;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;

/**
 * @author D063458
 *
 */
public class Row {

        public NamedEntity ne;
        public String parse;
        public int id;
        public Token token;
        public Collection<CoreferenceLink> coref;
 
}
